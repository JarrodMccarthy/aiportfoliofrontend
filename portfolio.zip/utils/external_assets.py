PLOTLY_LOGO = "https://images.plot.ly/logo/new-branding/plotly-logomark.png"

# link fontawesome to get the chevron icons
FONT_AWSOME = "https://use.fontawesome.com/releases/v5.8.1/css/all.css"

# your custom style
CUSTOM_STYLE = "https://codepen.io/chriddyp/pen/bWLwgP.css"