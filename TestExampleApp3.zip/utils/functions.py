def formatter_2_decimals(x):
	return "{:.2f}".format(x)