home_page_location = "/"
login_page_location = "/login_signup"
coveragemap_page_location = "/coveragemap"
deployables_page_location = "/deployables"
celfimonitoring_page_location = "/celfimonitoring"

TIMEOUT = 60