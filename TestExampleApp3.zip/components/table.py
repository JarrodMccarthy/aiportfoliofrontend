
import dash_html_components as html
import dash_table

def make_dash_table(df):
    table = dash_table.DataTable(id='table', columns=[{"name": i, "id": i} for i in df.columns],data=df.to_dict('records'),editable=True,export_format="xlsx",export_headers="display",)
    return table