import dash
from dash.dependencies import Input, Output
import dash_html_components as html
import dash_core_components as dcc
from app import app
#import googlemaps 
import requests


# @application.callback(
#     Output('location-output', 'children'),
#     Input('location-input', 'value')
# )
# def update_output(value):
#     if value != None:
#         API_KEY = 'AIzaSyDUfZ1PVGhHMF4_XKf4Sb7c9XwrnDAFMWI'
#         #gmaps = googlemaps.Client(key = API_KEY)
#         url = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input={}&types=geocode&key={}".format(value, API_KEY)
#         payload={}
#         headers = {}
#         response = requests.request("GET", url, headers=headers, data=payload)
#         return response.text