import dash_html_components as html
import dash_core_components as dcc
import dash_bootstrap_components as dbc
from app import app

import pandas as pd
import os

import plotly.express as px

from pages.home import home_callbacks

# file_path = os.path.join(os.getcwd(), 'data', 'site.csv')
# #aus_cities = pd.read_csv(file_path)

# fig = None
# #px.scatter_mapbox(aus_cities, lat="LATITUDE", lon="LONGITUDE", hover_name="NAME", hover_data=["STATE", "NAME", "SITE_PRECISION", "ELEVATION"],
#                         #color_discrete_sequence=["fuchsia"], zoom=3, height=800)
# fig.update_layout(
#     mapbox_style="open-street-map",
#     mapbox_layers=[
#         # {
#         #     "below": 'traces',
#         #     "sourcetype": "raster",
#         #     "sourceattribution": "United States Geological Survey",
#         #     "source": [
#         #         "https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer/tile/{z}/{y}/{x}"
#         #     ]
#         # },
#         # {
#         #     "below": 'traces',
#         #     "sourcetype": "raster",
#         #     "sourceattribution": "United States Geological Survey",
#         #     "source": [
#         #         "https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer/tile/{z}/{y}/{x}"
#         #     ]
#         # },
#         {
#             "sourcetype": "raster",
#             "sourceattribution": "Government of Canada",
#             "source": ["https://geo.weather.gc.ca/geomet/?"
#                        "SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&BBOX={bbox-epsg-3857}&CRS=EPSG:3857"
#                        "&WIDTH=1000&HEIGHT=1000&LAYERS=RADAR_1KM_RDBR&TILED=true&FORMAT=image/png"],
#         }
#       ])
# fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})

layout = dbc.Container([
    dbc.Row([
        dbc.Col(html.Div([dcc.Input(id="location-input", type="text", placeholder="Enter Location", style={'marginRight':'10px'})]), width="auto"),
        dbc.Col(html.Div(id='location-output', style={'whiteSpace': 'pre-line'}), width="auto")
    ]),
    html.Hr(),
    dbc.Row(
        [

            #dbc.Col(html.Div([dcc.Graph(figure=fig)]), width=12),
            # dbc.Col(html.Img(src=application.get_asset_url('logo.png')), width=3),
            # dbc.Col(html.Div(), width=3),
            # #dbc.Col(html.Img(src=application.get_asset_url('simple.png')), width=3),
        ],
        align="left",
    ),
    html.Hr(),
    dbc.Row()
])



