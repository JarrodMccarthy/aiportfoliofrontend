import dash_html_components as html
import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_daq as daq

from app import app

import pandas as pd
import os

import plotly.express as px

from pages.login import login_callbacks


layout = dbc.Container([
    html.Hr(),
    html.Div(
        [
            html.H4("Login | Sign Up", style={'text-align':'center'}),
            daq.ToggleSwitch(
                id='signup-login-sw',
                value=False,
                style={'padding': 20}
            ),
        ]
    ),
    html.Div(
        [
            html.Div(
                id='my-toggle-switch-output',
            ),
        ],
    ),
])



