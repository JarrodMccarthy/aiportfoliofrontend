import dash
from dash.dependencies import Input, Output
import dash_html_components as html
import dash_core_components as dcc
import dash_bootstrap_components as dbc
from app import app


@app.callback(
    Output('my-toggle-switch-output', 'children'),
    Input('signup-login-sw', 'value')
)
def update_output(value):
    if value: #returns Sign Up card
        card = dbc.Card(
            [
                html.Div(
                    [
                        html.H4("Sign Up", style={'text-align':'center'}),
                    ]
                ),
                html.Div(
                    [
                        html.Div([dcc.Input(id="signup-email", type="email", placeholder="Email?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5}),
                    ]
                ),
                html.Div(
                    [
                        html.Div([dcc.Input(id="signup-password", type="password", placeholder="Password?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5}),
                    ]
                ),
                html.Div(
                    [
                        html.Div([dcc.Input(id="firstname", type="text", placeholder="First?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5}),
                    ]
                ),
                html.Div(
                    [
                        html.Div([dcc.Input(id="lastname", type="text", placeholder="Last?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5}),
                    ]
                ),
                html.Div(
                    [
                        html.Div([dcc.Input(id="phone", type="tel", placeholder="Phone?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5}),
                    ]
                ),
                html.Div(
                    [
                        html.Div([html.Button('signup')], style={'padding': 15}),
                    ]
                ),
            ],
        ),
    else: 
        card = dbc.Card(
            [
                html.Div(
                    [
                        html.H4("Login", style={'text-align':'center'}),
                    ]
                ),
                html.Div(
                    [
                        html.Div([dcc.Input(id="login-email", type="email", placeholder="Email?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5})
                    ]
                ),
                html.Div(
                    [
                        html.Div([dcc.Input(id="login-password", type="password", placeholder="Password?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5}),
                    ]
                ),
                html.Div(
                    [
                        html.Div([html.Button('Login')], style={'padding': 15}),
                    ]
                ),
            ],
        ),
    return dbc.Row(card, justify="center")

# login = dbc.Card(
#             [
#                 html.Div(
#                     [
#                         html.H4("Login", style={'text-align':'center'}),
#                     ]
#                 ),
#                 html.Div(
#                     [
#                         html.Div([dcc.Input(id="login-email", type="email", placeholder="Email?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5})
#                     ]
#                 ),
#                 html.Div(
#                     [
#                         html.Div([dcc.Input(id="login-password", type="password", placeholder="Password?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5}),
#                     ]
#                 ),
#                 html.Div(
#                     [
#                         html.Div([html.Button('Login')], style={'padding': 15}),
#                     ]
#                 ),
#             ],
#         ),


# signup = dbc.Card(
#             [
#                 html.Div(
#                     [
#                         html.H4("Sign Up", style={'text-align':'center'}),
#                     ]
#                 ),
#                 html.Div(
#                     [
#                         html.Div([dcc.Input(id="signup-email", type="email", placeholder="Email?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5}),
#                     ]
#                 ),
#                 html.Div(
#                     [
#                         html.Div([dcc.Input(id="signup-password", type="password", placeholder="Password?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5}),
#                     ]
#                 ),
#                 html.Div(
#                     [
#                         html.Div([dcc.Input(id="firstname", type="text", placeholder="First?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5}),
#                     ]
#                 ),
#                 html.Div(
#                     [
#                         html.Div([dcc.Input(id="lastname", type="text", placeholder="Last?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5}),
#                     ]
#                 ),
#                 html.Div(
#                     [
#                         html.Div([dcc.Input(id="phone", type="tel", placeholder="Phone?", style={'width': '90%', 'text-align':'center'})], style={'text-align':'center', 'padding': 5}),
#                     ]
#                 ),
#                 html.Div(
#                     [
#                         html.Div([html.Button('signup')], style={'padding': 15}),
#                     ]
#                 ),
#             ],
#         ),